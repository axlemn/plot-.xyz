#!/usr/bin/env python
import sys
from run_script import update_file;
update_file(sys.argv[1])
