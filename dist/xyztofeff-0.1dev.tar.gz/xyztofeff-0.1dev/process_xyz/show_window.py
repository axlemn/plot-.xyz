#!/usr/bin/env python
import matplotlib.pyplot as plt
from matplotlib_script import *
import sys

make_window(sys.argv[1])
plt.show()
